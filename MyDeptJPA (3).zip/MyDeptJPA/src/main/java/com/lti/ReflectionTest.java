package com.lti;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;


class Flight
{
	
	private int flightNumber;
	
	static int runwayLength=2000;
	static int maxAltitude=10000;
	static int minAltitude=500;
	
	public Flight() { }
	public Flight(int i) { }
	public Flight(int i, int j) { }
	
	public void fly() { }
	public void land() { }
	
}
public class ReflectionTest {
	public static void main(String[] args) {
		
		Flight f = new Flight();
	
		
		Class theMirror = f.getClass(); //<-- code is being type by us - development
				//but for eclipse s/w it is deployment/live activity
		Method methods[] = theMirror.getMethods();
		for (Method method : methods) {
			System.out.println("Method is : "+method.getName());
		}
		System.out.println("---------------");
		Constructor ctor[] = theMirror.getConstructors();
		for (Constructor c: ctor) {
			System.out.println("Constructor : "+c.getName()+" with "+c.getParameterCount()+" arguments ");
		}
		
		/*ArrayList<Integer> myJukeBox = new ArrayList<Integer>();
		myJukeBox.add(100); // by default autoboxed into Integer(100)
		myJukeBox.add(100.0f); // by default autoboxed into Float(100.0f)
		myJukeBox.add(100.45); // by default autoboxed into Double(100.45)
		myJukeBox.add('A');   // by default autoboxed into Character(100.0f)
		
		myJukeBox.add("stringhere");
		*/
		
	}
}
