package com.lti.exceptions;

public class EmptyDepartmentException extends RuntimeException { } //public
