package com.lti.exceptions;

public class DepartmentNotFoundException extends RuntimeException 
{ } //public