package com.lti;

interface Flower
{
	void flowering(); // pure abstract 
}

class Rose implements Flower 
{
	public void flowering() {
		System.out.println("Rose is flowering...");
	}
}

class Lotus implements Flower
{
	public void flowering() {
		System.out.println("Lotus is flowering...");
	}
}

class Lilly implements Flower
{
	public void flowering() {
		System.out.println("Lilly is flowering...");
	}
}

class FlowerFactory
{
	static Flower getFlower(String someHint) { //promise to return/product Flower
		Flower f = null;
		if(someHint.equalsIgnoreCase("valentine"))
			f = new Rose();
		else if(someHint.equalsIgnoreCase("diwali"))
			f = new Lotus();
		else if(someHint.equalsIgnoreCase("friendship"))
			f = new Lilly();
		
		return f;
	}
}

public class FactoryTest {
	public static void main(String[] args) {
		
		
		//Rose r = new Rose(); //u will always get Rose, not any other flower
		//r.flowering();
		
		//Lotus l = new Lotus();
		//l.flowering();
		
		//Lilly l = new Lilly();
		//l.flowering();
		
		//flowergarden is a flowerfactory
		Flower f = FlowerFactory.getFlower("valentine");
		f.flowering(); 
		
	}
}
