package com.lti.dao; //there are 10 parameters on which project is evaluated - 40 marks with me - 60 marks with SME

import java.util.List;

import com.lti.exceptions.DepartmentAlreadyPresentException;
import com.lti.exceptions.DepartmentNotFoundException;
import com.lti.exceptions.DepartmentUpdateException;
import com.lti.exceptions.EmptyDepartmentException;
import com.lti.pojo.Department;
import com.lti.pojo.Employee;

//proper naming conventions, indentation, comments,  10 marks for it
public interface EmployeeDAO {
	
	//5 basic methods - CRUD operation
	void 			addEmployee(Employee d) throws DepartmentAlreadyPresentException;
	Employee 		findEmployeeByEmpNumber(int dno) throws DepartmentNotFoundException;
	List<Employee>  findAllEmployees() throws EmptyDepartmentException;
	void 			updateEmployee(Employee d) throws DepartmentUpdateException;
	void 			deleteEmployee(int eno) throws DepartmentNotFoundException;

}

//below exceptions are not part of DAO design pattern
//it is just a project perspective





/*
 * 					Object
 * 					|
 * 		-------------------------------
 * 		|					|
 * 		Error			Throwable <-- the main logic is written here
 * 						|
 * 			-------------------------------------
 * 				|						|
 * 			Exception				Error
 * 					|checked
 * 	------------------------------------------
 * 	|							|		|
 * RuntimeException		IOException  SQLException			
 *  | unchecked
 *  ------------------------------------------------------------
 *  |						 |  |                         |
 * DepartmentUpdateException |DepartmentNotFoundException |
 *      EmptyDepartmentException    DepartmentAlreadyPresentException
 * 
 * Exception e = new Exception("Department not found");
 * Exception e = new Exception("Department already present");
 * Exception e = new Exception("Department update problem");
 * 
 * try
 * {
 *   ...
 * }
 * catch() {
 *   measure by neurosurgeon
 * }
 * catch() {
 * 	measure by orthosurgeon
 * }
 * catch() {
 *   measure by heartsurgeon
 * }
 * 					Doctor
 * 					|
 * 			--------------------------
 * 			|
 * 			Surgeon <--Exception
 * 			| cut/stitching
 * 		-------------------------
 * 		|			|			|
 * NeuroSurgeon	 HeartSurgeon	OrthoSurgeon
 *  brain			heart			bones
 */

