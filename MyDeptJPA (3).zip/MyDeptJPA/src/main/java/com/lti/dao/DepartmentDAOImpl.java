package com.lti.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.lti.exceptions.DepartmentAlreadyPresentException;
import com.lti.exceptions.DepartmentNotFoundException;
import com.lti.exceptions.DepartmentUpdateException;
import com.lti.exceptions.EmptyDepartmentException;
import com.lti.pojo.Department;

public class DepartmentDAOImpl implements DepartmentDAO {

	EntityManagerFactory factory ;
	
	
	public DepartmentDAOImpl() {
		factory = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("EntityManagerFactory : "+factory);
	}
	
	//look at this addDepartment function - it is hiding all the code
	//from developer's point of view
	public void addDepartment(Department d) throws DepartmentAlreadyPresentException {
		EntityManager manager = factory.createEntityManager();
		System.out.println("EntityManager        : "+manager);
		EntityTransaction trans = manager.getTransaction();
		
		trans.begin();
			Department tmpDept=manager.find(Department.class, d.getDepartmentNumber());
			if(tmpDept!=null) { //if the row found
				System.out.println("Department already present");
				DepartmentAlreadyPresentException dape = new DepartmentAlreadyPresentException("Such deptno already present!!!");
				throw dape;
				//throw new DepartmentAlreadyPresentException();
			} //use Junit Assertion here
			System.out.println("adding new department..");
			manager.persist(d); //persist will throw constraint violation exception 
		trans.commit();
	}

	public Department findDepartmentByDeptNumber(int dno) throws DepartmentNotFoundException {
		// TODO Auto-generated method stub
		EntityManager manager = factory.createEntityManager();
		System.out.println("EntityManager        : "+manager);
		EntityTransaction trans = manager.getTransaction();
		trans.begin();
			Department d =  manager.find(Department.class,dno);
			if(d == null) {
				throw new DepartmentNotFoundException();
			}
		trans.commit();
		return d;
	}

	public List<Department> findAllDepartments() throws EmptyDepartmentException {
		// TODO Auto-generated method stub
		return null;
	}

	public void updateDepartment(Department d) throws DepartmentUpdateException {
		// TODO Auto-generated method stub

	}

	public void deleteDepartment(int dno) throws DepartmentNotFoundException {
		// TODO Auto-generated method stub

	}

}
