package com.lti.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.lti.exceptions.DepartmentAlreadyPresentException;
import com.lti.exceptions.DepartmentNotFoundException;
import com.lti.exceptions.DepartmentUpdateException;
import com.lti.exceptions.EmptyDepartmentException;
import com.lti.pojo.Department;

public class DepartmentDAOImpl2 extends BaseDAO implements DepartmentDAO {

	EntityManagerFactory factory ;
	
	
	public DepartmentDAOImpl2() {
		factory = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("EntityManagerFactory : "+factory);
	}
	
	//look at this addDepartment function - it is hiding all the code
	//from developer's point of view
	public void addDepartment(Department d) throws DepartmentAlreadyPresentException {
		super.merge(d);
	}

	public Department findDepartmentByDeptNumber(int dno) throws DepartmentNotFoundException {
		// TODO Auto-generated method stub
		EntityManager manager = factory.createEntityManager();
		System.out.println("EntityManager        : "+manager);
		EntityTransaction trans = manager.getTransaction();
		trans.begin();
			Department d =  manager.find(Department.class,dno);
			if(d == null) {
				throw new DepartmentNotFoundException();
			}
		trans.commit();
		return d;
	}

	public List<Department> findAllDepartments() throws EmptyDepartmentException {
		// TODO Auto-generated method stub
		return null;
	}

	public void updateDepartment(Department d) throws DepartmentUpdateException {
		// TODO Auto-generated method stub

	}

	public void deleteDepartment(int dno) throws DepartmentNotFoundException {
		// TODO Auto-generated method stub

	}

}
