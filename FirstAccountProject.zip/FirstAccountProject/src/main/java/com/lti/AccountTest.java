package com.lti;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class AccountTest {
	public static void main(String[] args) {
		
		//code to load the hibernate framework
		
		Configuration cfg = new Configuration(); //it will load the properties file
		cfg.addAnnotatedClass(com.lti.Account.class); //class Class 
		
		SessionFactory factory = cfg.buildSessionFactory(); 
		
		System.out.println("=> Factory created : "+factory);
		
		Session mySession = factory.getCurrentSession();  					
		System.out.println("=> Got the session : "+mySession);
		
		//ACID 
		Transaction myTransaction = mySession.beginTransaction(); 			
		System.out.println("=> Started the transaction : "+myTransaction);
			
			Account a1 = new Account();
			System.out.println("Account blank object ready...");
		
			a1.setAccountNumber(104);
			a1.setAccountHolderName("Robert");
			a1.setAccountBalance(10000);
		
			System.out.println("Account Object is filled up ");
		
			System.out.println("Trying to persist the Account's object...");
			mySession.save(a1);
			System.out.println("Account Object persisted ...");
		myTransaction.commit();
		
		factory.close();
		System.out.println("Factory is closed...");
		
	}
}
