package com.lti;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

//this class would be mapped as per the table

//CRUD - create, read, update, delete

@Entity
@Table(name="account")
public class Account { // is account table mapped with class Account?
	
	@Id
	private int accountNumber; // is accountNumber mapped as a primary key with acno?
	
	private String accountHolderName; // acname
	private float accountBalance; // acbal
	
	
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public float getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(float accountBalance) {
		this.accountBalance = accountBalance;
	}
	
	
}
