import { BusRoute } from './BusRoute';

export class Reservation {
    ticketno: number;
    bookingdate: Date;
    journeydate: Date;
    cancellationdate: Date;
    
    busroute: BusRoute;

    refund: number;
    rescheduledate: Date;
    seatno: number;
    ticketstatus: string;
    transactionid: number;
}