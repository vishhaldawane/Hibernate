export class Department {
    deptNumber : number;
    deptName : string;
    deptLocation : string;
}

export class FlightDetails { // fields of this class must have same name
    flightNumber : number;      //as of the JAVA's pojo fields
    flightName : string;
    //other 2 fields too
}
export class Question {
    queNum : number;
    question: string;
    rightAnswer: string;

    option1: string;
    option2: string;
    option3: string;
    option4: string;

}
export class StudentResponse {
    studeRoll: number;
    question: Question;
    resp:   string;
}





