import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Department, FlightDetails } from './department';

@Injectable({
  providedIn: 'root'
})
export class DepartmentService {

  baseUrl: string = 'http://localhost:8085/DeptManagement/rest/DepartmentService/';
  baseUrl1: string = 'http://localhost:8080/';

  constructor(private myhttp:HttpClient) { }

  findDepartment(deptNumber: number): Observable<Department> 
  {
    return this.myhttp.get<Department>(this.baseUrl + "getDept/" + deptNumber);
  }

  findAllDepartments() :Observable<Department[]>
  {
    return this.myhttp.get<Department[]>(this.baseUrl1+"getDepts/");
  }   //http://localhost:8085/getFlights --> this will produce JSON data
    //and shown on the browser ( which we dont want) rather we want
    // that json array to be consumed by our angular app
    

  
  findAllFlights() :Observable<FlightDetails[]>
  {
    return this.myhttp.get<FlightDetails[]>(this.baseUrl+"getFlights/");
  } //                                     localhost:8080/getFlights

  addNewDeparment(newDept: Department): Observable<Department>
  {
    //you can do some activity here which is client specific
    //
    return this.myhttp.post<Department>(this.baseUrl+"addDept/",newDept);
  }

  modifyDeparment(existingDept: Department): Observable<Department>
  {
    return this.myhttp.put<Department>(this.baseUrl + "updateDept/", existingDept);
  } 
  
  deleteDeparment(deptNumber: number) : Observable<Department>
  {
    return this.myhttp.delete<Department>(this.baseUrl + "deleteDept/" + deptNumber);
                    
  }

}
