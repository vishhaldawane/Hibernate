import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-department',
  templateUrl: './update-department.component.html',
  styleUrls: ['./update-department.component.css']
})
export class UpdateDepartmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
