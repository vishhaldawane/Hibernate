import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs/internal/Subscription';
import { Department } from '../department';
import { DepartmentService } from '../department.service';

@Component({
  selector: 'app-view-all-department',
  templateUrl: './view-all-department.component.html',
  styleUrls: ['./view-all-department.component.css']
})
export class ViewAllDepartmentComponent implements OnInit {
  deptNo: number = 0;

  depts: Department[]; //will have all the records of the DB< -> Dept table
  tempDepts: Department[]; // will have the copy of the depts array above

  private subscription: Subscription;
  
  constructor(private deptService: DepartmentService) { }
  // http://localhost:4200/category
  ngOnInit() {
    // subscribe will read the latest category vale
    //u can have a direct call to http
    //TEA is prepared   
    //TEa five star hotel

    //separete Sugar Cube, TeaBags, hot water, boiled milk, 
    //5 people can have diff choice 
    //five Tea against 5 star biryani
    
    this.subscription = this.deptService.findAllDepartments()
    .subscribe((data: Department[]) => { // hold the data of DB into this data array
                    this.depts = data; //copy data array into depts array
                    this.tempDepts = data; //copy it to tempDeps array also
                   // console.log(this.tempDepts);
                   // console.log(this.depts);
                }, (err) => {
                    console.log(err);
                });
    }

    deleteDepartment(x: number) //28
    {
      //alert('deleting department '+deptNumber);
      console.log('dept number searched '+x);
      this.deptService.deleteDeparment(x)
      .subscribe((data: Department) => {
        
        if(data == null)  {
          this.tempDepts = this.depts.filter(d => (d.deptNumber != x) ); //10 20 25 30 40 
          this.depts = this.tempDepts; //only unmatched rows are copied to depts
          console.log('Record deleted '+x);
        }
        /*else {
          console.log(x+' is NOT matched : '+data.deptNumber);
          this.tempDepts = this.depts;
        }*/

    }, (err) => {
        console.log(err);
    });
    }

    updateDepartmentArray() { //update the "htmlViewAllRecords" if reecord is searched by entering 0 or notning or any number
      if(this.deptNo == 0)  {
        console.log('its zero : '+this.deptNo);
        this.tempDepts = this.depts;
      }
      else {
        console.log('its not zero : '+this.deptNo);
        this.tempDepts = this.depts.filter(d => (d.deptNumber == this.deptNo) );
        //console.log('d : '+d.deptNumber+ '  dname : '+d.deptName+ ' dloc : '+d.deptLocation);
        console.log('tempDepts length : '+this.tempDepts.length);
        console.log('depts length : '+this.depts.length);
        
      }
      
    }
}
