import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Reservation } from './reservation';

@Injectable({
  providedIn: 'root'
})
export class ReservationService {

  baseUrl: string = 'http://localhost:8085/';
  constructor(private myhttp:HttpClient) { }

  findReservation(ticketNumber: number): Observable<Reservation> 
  {
    return this.myhttp.get<Reservation>(this.baseUrl + "getReservation/" + ticketNumber);
  }

  findAllReservations() :Observable<Reservation[]>
  {
    return this.myhttp.get<Reservation[]>(this.baseUrl+"getAllReservations/");
  }

  addNewReservation(newReservation: Reservation): Observable<Reservation>
  {
    //you can do some activity here which is client specific
    //
    return this.myhttp.post<Reservation>(this.baseUrl+"addReservation/",newReservation);
  }

  modifyReservation(existingReservation: Reservation): Observable<Reservation>
  {
    return this.myhttp.put<Reservation>(this.baseUrl + "updateReservation/", existingReservation);
  }
  
  deleteReservation(ticketNumber: number) : Observable<Reservation>
  {
    return this.myhttp.delete<Reservation>(this.baseUrl + "deleteReservation/" + ticketNumber);
                    
  }

}
