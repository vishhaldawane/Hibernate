package com.lti;

public class DepartmentAlreadyPresentException extends Exception { 
	
	DepartmentAlreadyPresentException (String msg) { super(msg); }
} 