package com.lti;

public class DepartmentNotFoundException extends RuntimeException { } //public