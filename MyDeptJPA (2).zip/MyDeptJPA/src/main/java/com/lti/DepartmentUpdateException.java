package com.lti;

public class DepartmentUpdateException extends RuntimeException { } //public
