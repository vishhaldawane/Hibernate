package com.lti;

public class EmptyDepartmentException extends RuntimeException { } //public
