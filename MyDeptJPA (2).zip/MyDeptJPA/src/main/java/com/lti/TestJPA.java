package com.lti;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.junit.Test;


public class TestJPA {
	
	@Test
	public void insertDept() {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("MyJPA"); 		System.out.println("EntityManagerFactory : "+factory);
		EntityManager manager = factory.createEntityManager();		System.out.println("EntityManager        : "+manager);
		EntityTransaction trans = manager.getTransaction();		System.out.println("EntityTransaction    : "+trans);
		trans.begin();
			Department d1 = new Department();
			d1.setDepartmentNumber(60);
			d1.setDepartmentName("Projects");
			d1.setDepartmentLocation("Pune");
			manager.persist(d1); // session.save(d1)
		trans.commit();
		System.out.println("Done");
	}
	
	@Test
	public void insertDeptAgain() {
		DepartmentDAOImpl deptDao = new DepartmentDAOImpl();
		Department d = new Department();
		d.setDepartmentNumber(70);
		d.setDepartmentName("QMS");
		d.setDepartmentLocation("Delhi");
		try {
			deptDao.addDepartment(d);
		} catch (DepartmentAlreadyPresentException e) {

			System.out.println("Problem : "+e);
		} //dao function isTakingCare of EMF EM ET
		System.out.println("Done");
	}
	
	
	@Test
	public void selectDept() {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("EntityManagerFactory : "+emf);
		
		EntityManager em = emf.createEntityManager();
		System.out.println("EntityManager        : "+em);
		
		EntityTransaction et = em.getTransaction();
		System.out.println("EntityTransaction    : "+et);
		
		et.begin();
			Department d1 = em.find(Department.class,10); //session.get(10);
			
			System.out.println("DeptNumber :"+d1.getDepartmentNumber());
			System.out.println("DeptName   :"+d1.getDepartmentName());
			System.out.println("DeptLoc    :"+d1.getDepartmentLocation());
			
		et.commit();
		System.out.println("Done");
	}
	
	@Test
	public void selectDeptAgain() { //observe the low level Data access is hidden
			DepartmentDAOImpl deptDao = new DepartmentDAOImpl();
			Department d1 = deptDao.findDepartmentByDeptNumber(10);//hb+db codeBehind
			System.out.println("DeptNumber :"+d1.getDepartmentNumber());
			System.out.println("DeptName   :"+d1.getDepartmentName());
			System.out.println("DeptLoc    :"+d1.getDepartmentLocation());
			System.out.println("Done");
	}

	
	@Test
	public void updateDept() {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("EntityManagerFactory : "+emf);
		
		EntityManager em = emf.createEntityManager();
		System.out.println("EntityManager        : "+em);
		
		EntityTransaction et = em.getTransaction();
		System.out.println("EntityTransaction    : "+et);
		
		et.begin();
			Department d1 = em.find(Department.class,50);
			
			System.out.println("DeptNumber :"+d1.getDepartmentNumber());
			System.out.println("DeptName   :"+d1.getDepartmentName());
			System.out.println("DeptLoc    :"+d1.getDepartmentLocation());
			
			d1.setDepartmentName("TRG");
			d1.setDepartmentLocation("MUM");
			
			em.merge(d1); //saveOrUpdate(d1); // update(d1);
			
		et.commit();
		System.out.println("Done");
	}
	
	@Test //core java, mar java, mit java, loot java
	
	public void deleteDept() {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("EntityManagerFactory : "+emf);
		
		EntityManager em = emf.createEntityManager();
		System.out.println("EntityManager        : "+em);
		
		EntityTransaction et = em.getTransaction();
		System.out.println("EntityTransaction    : "+et);
		
		et.begin();
			Department d1 = em.find(Department.class, 60);
		
			em.remove(d1); //session.delete(d1);
			
		et.commit();
		System.out.println("Done");
	}
	
	@Test
	public void selectAllDepts() {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("EntityManagerFactory : "+emf);
		
		EntityManager em = emf.createEntityManager();
		System.out.println("EntityManager        : "+em);
		
		EntityTransaction et = em.getTransaction();
		System.out.println("EntityTransaction    : "+et);
		
		et.begin();
			
			Query qry = em.createQuery("from Department", Department.class);
			List<Department> deptList = qry.getResultList();
			
			for (Department x : deptList) {
				System.out.println("DeptNumber :"+x.getDepartmentNumber());
				System.out.println("DeptName   :"+x.getDepartmentName());
				System.out.println("DeptLoc    :"+x.getDepartmentLocation());	
			}
			
			
			
		et.commit();
		System.out.println("Done");
	}
	
}
