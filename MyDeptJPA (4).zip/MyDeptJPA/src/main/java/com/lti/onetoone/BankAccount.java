package com.lti.onetoone;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="bankaccount")
public class BankAccount { // drop table bankaccoun cascade constraints
	
	@Id
	@Column(name="acno")
	private int accountNumber;
	
	@Column(name="acname",length=20)
	private String accountHolderName;
	
	@Column(name="acbal")
	private double accountBalance;
	
	//but the fourth is FK
	@OneToOne( cascade = CascadeType.ALL)
	@JoinColumn(name="panno",  unique = true) // add this unique=true
	private PanCard pan; // it should point to a row
	
	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	public PanCard getPan() {
		return pan;
	}

	public void setPan(PanCard pan) {
		this.pan = pan;
	}
	
	
}
