package com.lti.onetoone;

import org.junit.Test;

import com.lti.dao.BaseDAO;

public class TestOneToOne {
	
	@Test
	public void insertBankAccountAndPanCard() {
		
		PanCard pan3= new PanCard(); //non existing- transiet object
		//RURYE2244T	Reema E Shah 2/11/91  Eshwar Shah  Govt. of India
		pan3.setPanNumber("RURYE2244T");		pan3.setNameOnPan("Reema E Shah");
		pan3.setFathersName("Eshwar Shah");		pan3.setBirthDate("1/11/91");
		pan3.setIssuedBy("Govt. of India");		
		
		//22	2200	Reema  
		BankAccount ba3 = new BankAccount();
		ba3.setAccountNumber(103);	ba3.setAccountHolderName("Reema");
		ba3.setAccountBalance(2200);
		
		pan3.setBank(ba3); //pan is aware of bankaccount
		ba3.setPan(pan3); //bankaccount is aware of pan
		
		BaseDAO dao = new BaseDAO();
		dao.merge(pan3);
		
	}
	
	@Test
	public void insertBankAccountAndPanCardAgain() {

		//MURYE3245Q Mitesh R Modi 4/09/92 Rakesh Modi Govt. of India
		PanCard pan4= new PanCard(); //non existing- transiet object
		pan4.setPanNumber("MURYE3245Q");		pan4.setNameOnPan("Mitesh R Modi");
		pan4.setFathersName("Rakesh Modi");		pan4.setBirthDate("4/09/92");
		pan4.setIssuedBy("Govt. of India");		
		
		// 103	2000	Mitesh  
		BankAccount ba4 = new BankAccount();
		ba4.setAccountNumber(104);	ba4.setAccountHolderName("Mitesh");
		ba4.setAccountBalance(2200);
		
		pan4.setBank(ba4); //pan is aware of bankaccount - awareness of who the bank acc is
		
		ba4.setPan(pan4); //bankaccount is aware of pan - FK setting here
		
		BaseDAO dao = new BaseDAO();
		dao.merge(pan4); //only merge pan4 (will merge the ba4 too )
		
	}
	
	@Test
	public void insertBankAccounts() {
		BaseDAO dao = new BaseDAO();
		
		BankAccount ba1 = new BankAccount();
		ba1.setAccountNumber(101);	ba1.setAccountHolderName("Adesh");
		ba1.setAccountBalance(5000);		dao.persist(ba1);
		
		BankAccount ba2 = new BankAccount();
		ba2.setAccountNumber(102);	ba2.setAccountHolderName("Subin");
		ba2.setAccountBalance(6000);		dao.persist(ba2);
		
		
	}
	@Test
	public void insertPanCard() {
		BaseDAO dao = new BaseDAO();
		PanCard pan1= new PanCard();
		PanCard pan2= new PanCard();
		//AURYD1234F Adesh S Jain 1/12/90  Sumit Jain   Govt. of India
		pan1.setPanNumber("AURYD1234F");		pan1.setNameOnPan("Adesh S Jain ");
		pan1.setFathersName("Sumit Jain");		pan1.setBirthDate("1/12/90");
		pan1.setIssuedBy("Govt. of India");		dao.persist(pan1);
		
		//SUERQ4738W Subin T Wora 3/12/90  Tejas Wora   Govt. of India
		pan2.setPanNumber("SUERQ4738W");		pan2.setNameOnPan("Subin T Wora");
		pan2.setFathersName("Tejas Wora");		pan2.setBirthDate("3/12/90");
		pan2.setIssuedBy("Govt. of India");		dao.persist(pan2);
	}
	@Test 
	public void assignExisingPanToExistingBankAccount() { 
		BaseDAO dao = new BaseDAO();
		PanCard  panObj1 	= dao.find(PanCard.class, "AURYD1234F"); //attached to the session
		PanCard  panObj2 	= dao.find(PanCard.class, "SUERQ4738W");
		
		BankAccount bankObj1 = dao.find(BankAccount.class,101);
		BankAccount bankObj2 = dao.find(BankAccount.class,102);
		
		bankObj1.setAccountHolderName("AADESH"); //not required
		bankObj1.setAccountBalance(bankObj1.getAccountBalance()+1000); //not required
		bankObj1.setPan(panObj1); // here it will update FK->panno column from PK->pannum
		
		bankObj2.setAccountHolderName("SUBIN"); //not required
		bankObj2.setAccountBalance(bankObj2.getAccountBalance()+1000); //not required
		bankObj2.setPan(panObj2); // here it will update FK->panno column from PK->pannum
		
		dao.merge(bankObj1);
		dao.merge(bankObj2);
	}
	
	@Test
	public void showBankDetailsViaPanCard() 	{
		BaseDAO dao = new BaseDAO();
		PanCard  panObj 	= dao.find(PanCard.class, "SUERQ4738W");
		
		System.out.println("-- Fetching Bank details Via PanCard number -- ");
		BankAccount baDetails = panObj.getBank();
		System.out.println("Account Number      : "+baDetails.getAccountNumber());
		System.out.println("Account Holder Name : "+baDetails.getAccountHolderName());
		System.out.println("Account Balance     : "+baDetails.getAccountBalance());
	}
	
	@Test
	public void showPanDetailsViaBankAccount() 	{ //then we will see delete also via dao
		BaseDAO dao = new BaseDAO();
		BankAccount bankObj = dao.find(BankAccount.class,102);
		
		System.out.println("-- Fetching Pan details Via Bank Account -- ");
		PanCard pc = 	bankObj.getPan();
		System.out.println("Name on Pan Card    : "+pc.getNameOnPan());
		System.out.println("DOB on Pan          : "+pc.getBirthDate());
		System.out.println("Father name on Pan  : "+pc.getFathersName());
		System.out.println("Pan Issued By       : "+pc.getIssuedBy());
	}
	
	@Test
	public void deleteBankAccount() {
		BaseDAO dao = new BaseDAO();
	BankAccount bankObj = 
	dao.getReference(BankAccount.class,102);
		dao.remove(bankObj);
	}
	//AURYD1234F
	
	@Test
	public void deletePanCard() {
		BaseDAO dao = new BaseDAO();
		PanCard  panObj 	= dao.getReference(PanCard.class, "AURYD1234F");
		dao.remove(panObj);
	}
}
