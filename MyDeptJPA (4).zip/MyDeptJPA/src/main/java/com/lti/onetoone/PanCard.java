package com.lti.onetoone;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="pancard")
public class PanCard {
	
	@Id
	@Column(name="pannum",length=10)
	private String panNumber;
	
	@Column(name="panname",length=20)
	private String nameOnPan;
	
	@Column(name="dob",length=20)
	private String birthDate;
	
	@Column(name="father",length=20)
	private String fathersName;
	
	@Column(name="issuedby",length=20)
	private String issuedBy;
	
	@OneToOne(mappedBy = "pan", cascade = CascadeType.ALL)
	private BankAccount bank;
	
	
	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public String getNameOnPan() {
		return nameOnPan;
	}

	public void setNameOnPan(String nameOnPan) {
		this.nameOnPan = nameOnPan;
	}

	public String getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}

	public String getFathersName() {
		return fathersName;
	}

	public void setFathersName(String fathersName) {
		this.fathersName = fathersName;
	}

	public String getIssuedBy() {
		return issuedBy;
	}

	public void setIssuedBy(String issuedBy) {
		this.issuedBy = issuedBy;
	}
	
	public BankAccount getBank() {
		return bank;
	}

	public void setBank(BankAccount bank) {
		this.bank = bank;
	}
	
}
