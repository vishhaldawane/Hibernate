package com.lti.dao; //there are 10 parameters on which project is evaluated - 40 marks with me - 60 marks with SME

import java.util.List;

import com.lti.exceptions.DepartmentAlreadyPresentException;
import com.lti.exceptions.DepartmentNotFoundException;
import com.lti.exceptions.DepartmentUpdateException;
import com.lti.exceptions.EmptyDepartmentException;
import com.lti.pojo.Department;

//proper naming conventions, indentation, comments,  10 marks for it
public interface DepartmentDAO {
	
	//5 basic methods - CRUD operation
	void 			addDepartment(Department d) throws DepartmentAlreadyPresentException;
	Department  	findDepartmentByDeptNumber(int dno) throws DepartmentNotFoundException;
	List<Department>findAllDepartments() throws EmptyDepartmentException;
	void 			updateDepartment(Department d) throws DepartmentUpdateException;
	void 			deleteDepartment(int dno) throws DepartmentNotFoundException;

}

//below exceptions are not part of DAO design pattern
//it is just a project perspective





/*
 * 					Object
 * 					|
 * 		-------------------------------
 * 		|					|
 * 		Error			Throwable <-- the main logic is written here
 * 						|
 * 			-------------------------------------
 * 				|						|
 * 			Exception				Error
 * 					|checked
 * 	------------------------------------------
 * 	|							|		|
 * RuntimeException		IOException  SQLException			
 *  | unchecked
 *  ------------------------------------------------------------
 *  |						 |  |                         |
 * DepartmentUpdateException |DepartmentNotFoundException |
 *      EmptyDepartmentException    DepartmentAlreadyPresentException
 * 
 * Exception e = new Exception("Department not found");
 * Exception e = new Exception("Department already present");
 * Exception e = new Exception("Department update problem");
 * 
 * try
 * {
 *   ...
 * }
 * catch() {
 *   measure by neurosurgeon
 * }
 * catch() {
 * 	measure by orthosurgeon
 * }
 * catch() {
 *   measure by heartsurgeon
 * }
 * 					Doctor
 * 					|
 * 			--------------------------
 * 			|
 * 			Surgeon <--Exception
 * 			| cut/stitching
 * 		-------------------------
 * 		|			|			|
 * NeuroSurgeon	 HeartSurgeon	OrthoSurgeon
 *  brain			heart			bones
 */

