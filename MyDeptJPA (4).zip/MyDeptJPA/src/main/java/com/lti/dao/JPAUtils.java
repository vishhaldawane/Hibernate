package com.lti.dao;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
//RC HA MT POR COR TM SM
public class JPAUtils { //this class is acting as a support to BaseDAO class
	private static EntityManagerFactory factory; //just a null reference
	public static EntityManagerFactory getEntityManagerFactory() {	
		return factory; }
	static { //initialize this null reference - this block would run only ONCE
		factory = Persistence.createEntityManagerFactory("MyJPA"); //hence factory is ONCE
		System.out.println("EntityManagerFactory : "+factory);
		Runtime.getRuntime().addShutdownHook(
				new Thread() { //annonymous inner class code bracket starts here
					public void run() { //
						factory.close(); //close the entitymanager factory 
					}
				} //annonymous inner class code bracket closed here
		);//<--- semicolon here
	}	//can u close the door twice 
}

/*
 * @Test public void testInsert() {
 * 
 * }
 */
