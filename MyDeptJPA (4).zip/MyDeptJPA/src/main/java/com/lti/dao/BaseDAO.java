package com.lti.dao;

import java.io.Serializable;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import com.lti.pojo.Department;

public class BaseDAO {
	EntityManagerFactory factory ; // super class data member
	public BaseDAO() {	factory = JPAUtils.getEntityManagerFactory();} //then we will add 5 basic functions for add select, update, delete, selectAll
	
	//five basic functions to CRUD
	public void persist(Object obj) { //this is user defined function name
		EntityManager manager = null;
		
			try
			{
				manager = factory.createEntityManager();
				EntityTransaction trans = manager.getTransaction();
				trans.begin();	manager.persist(obj); 	trans.commit();
			}
			finally {
				manager.close();
			}
	}
	public void merge(Object obj) { //this is user defined function name
		EntityManager manager = null;
			try
			{
				manager = factory.createEntityManager();
				EntityTransaction trans = manager.getTransaction();
				trans.begin(); manager.merge(obj); 	trans.commit();
			}
			finally {
				manager.close();
			}
	}
	
	public void remove(Object obj) { //this is user defined function name
		EntityManager manager = null;
			try
			{
				manager = factory.createEntityManager();
				EntityTransaction trans = manager.getTransaction();
				trans.begin(); 	manager.remove(obj); trans.commit();
			}
			finally {
				manager.close();
			}
	}
				//below is not an extension as .class - rather it is static data member as "class"
											//Employee.class / Customer.class
	public <AnyClassType> AnyClassType find(Class<AnyClassType> classname, Serializable pk) 	
	{ 
			EntityManager manager = null;
			AnyClassType e	= null;
			try 
			{
				manager = factory.createEntityManager();
				EntityTransaction trans = manager.getTransaction();
				trans.begin();
				e = manager.find(classname,pk); // actual persist method is invoked here
				trans.commit();
			}	
			finally {
				manager.close();			
			}
			return e;
	}
	/*public Department find(Class x , int num) 	{
	EntityManager manager = factory.createEntityManager();
	Department d = manager.find(x, num);
	return d;
}*/

//<E> below used to make a template function in core java
//reflection in core java - 
//Object as a parent class
//in this class there is a function that returns -> Class getClass()
	
	public <E> E getReference(Class<E> classname, Serializable pk) {
		EntityManagerFactory entityManagerFactory = JPAUtils.getEntityManagerFactory();
		EntityManager entityManager = null;
		try {
			entityManager = entityManagerFactory.createEntityManager();
			E e = entityManager.getReference(classname, pk);
			return e;
		}
		finally {		// we are on lunch break till 14.00 to 15.00 hours
			entityManager.close();			
		}
	}
	

	@SuppressWarnings("unchecked")
	public <E> List<E> getAll(String entityName) {
		EntityManagerFactory factory = JPAUtils.getEntityManagerFactory();
		EntityManager manager = null;
		try {
			manager = factory.createEntityManager();
			Query query = manager.createQuery(" from "+entityName);
			return query.getResultList();
		}
		finally {
			manager.close();			
		}
	}
	
}

class MyStack1
{
	int ary[]; //only for int
	
	void push(int i) { //only for int
		
	}
	int pop() { //only for int
		return 10;
	}
}
//template class and template function
class MyStack2<AnyType> // here < bracket is given at class level
{
	AnyType ary[]; //here it is DATATYPE
	int index=-1;
	
	//here it is ARGUMENT TYPE
	void push(AnyType i) { // < bracket is not given at function level
		ary[++index]=i; // store the data
	}
	
	//here it is RETURNTYPE
	AnyType pop() {
		return ary[index--]; //
	}
}
// MyStack1 ms1 = new MyStack1(); //  
// MyStack2<Float> ms2 = new MyStack2<Float>();
// MyStack2<Double> ms3 = new MyStack2<Double>();
// MyStack2<Flight> ms3 = new MyStack2<Flight>();
