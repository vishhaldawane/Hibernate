package com.lti.exceptions;

public class DepartmentAlreadyPresentException extends Exception { 
	
	public DepartmentAlreadyPresentException (String msg) { super(msg); }
} 