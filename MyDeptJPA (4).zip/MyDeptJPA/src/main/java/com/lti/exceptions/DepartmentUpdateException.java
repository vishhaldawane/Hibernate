package com.lti.exceptions;

public class DepartmentUpdateException extends RuntimeException { } //public
