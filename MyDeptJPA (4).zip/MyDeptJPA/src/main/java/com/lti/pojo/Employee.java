package com.lti.pojo;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="emp")
public class Employee {
	 /* EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
	  ---------- ---------- --------- ---------- --------- ---------- ----------
	      DEPTNO
	   */   
	@Id
	@Column(name="empno", length=5)
	private int employeeNumber;
	
	@Column(name="ENAME", length=10)
	private String employeeName;
	
	@Column(name="JOB", length=10)
	private String employeejob;
	
	@Column(name="MGR", length=5)
	private int employeesManager;
	
	@Column(name="HIREDATE")
	private Date employeeHiredate;
	
	@Column(name="SAL", length=10)
	private double employeeSalary;
	
	@Column(name="COMM", length=4)
	private double employeeCommision;
	
	@Column(name="DEPTNO", length=4)
	private int employeeDepartmentNumber;
	
	
	public int getEmployeeNumber() {
		return employeeNumber;
	}
	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getEmployeejob() {
		return employeejob;
	}
	public void setEmployeejob(String employeejob) {
		this.employeejob = employeejob;
	}
	public int getEmployeesManager() {
		return employeesManager;
	}
	public void setEmployeesManager(int employeesManager) {
		this.employeesManager = employeesManager;
	}
	public Date getEmployeeHiredate() {
		return employeeHiredate;
	}
	public void setEmployeeHiredate(Date employeeHiredate) {
		this.employeeHiredate = employeeHiredate;
	}
	public double getEmployeeSalary() {
		return employeeSalary;
	}
	public void setEmployeeSalary(double employeeSalary) {
		this.employeeSalary = employeeSalary;
	}
	public double getEmployeeCommision() {
		return employeeCommision;
	}
	public void setEmployeeCommision(double employeeCommision) {
		this.employeeCommision = employeeCommision;
	}
	public int getEmployeeDepartmentNumber() {
		return employeeDepartmentNumber;
	}
	public void setEmployeeDepartmentNumber(int employeeDepartmentNumber) {
		this.employeeDepartmentNumber = employeeDepartmentNumber;
	}
	
	
	
}
