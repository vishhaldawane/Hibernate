package com.lti.onetomany;

import java.util.HashSet;
import java.util.Set;

import org.junit.Test;

import com.lti.dao.BaseDAO;

public class TestOneToMany {
	
	@Test
	public void addDepartment() //ONE DEPARTMENT
	{
		MyDept d1 = new MyDept();
		d1.setDepartmentNumber(10);		d1.setDepartmentName("QMS");
		d1.setDepartmentLocation("Pune");
		BaseDAO dao = new BaseDAO();
		dao.persist(d1);
	}
	@Test
	public void addEmployee()	{ // MANY EMPLOYEES
		MyEmployee e1 = new MyEmployee();
		e1.setEmployeeNumber(101);		e1.setEmployeeName("Jack");
		e1.setEmployeeSalary(5000);
		BaseDAO dao = new BaseDAO();
		dao.persist(e1);
	}
	@Test
	public void assignExistingDeptToExistingEmployee() 	{
		BaseDAO dao = new BaseDAO();
		MyDept     d1 = dao.find(MyDept.class, 10);
		MyEmployee e1 = dao.find(MyEmployee.class, 101);
		e1.setDepartment(d1); //fillup the FK (dno) for the e1
		dao.merge(e1); //invokes the update query
	}
	
	@Test
	public void assignExistingDeptToNewEmployees()
	{
		BaseDAO dao = new BaseDAO();
		MyDept     d1 = dao.find(MyDept.class, 10);
		
		MyEmployee e1 = new MyEmployee(102, "JILL", 5500, d1);
		MyEmployee e2 = new MyEmployee(103, "BILL", 6600, d1);
		MyEmployee e3 = new MyEmployee(104, "GILL", 7700, d1);
		
		Set<MyEmployee> emps = new HashSet<MyEmployee>(); //blank set
		emps.add(e1); //triggers insert query to myemp table
		emps.add(e2); //triggers insert query to myemp table
		emps.add(e3); //triggers insert query to myemp table
		d1.setEmployees(emps); //d1 is aware of the Set of Employees now
		//above line will trigger the updation of d1
		dao.merge(d1);
	}
	//will be back in two mnts
	
	@Test
	public void addEmployeesAlongWithDept()
	{
		
		MyDept d2 = new MyDept();
		MyDept d3 = new MyDept();
		
		d2.setDepartmentNumber(20);
		d2.setDepartmentName("Testing");
		d2.setDepartmentLocation("Chennai");
		
		d3.setDepartmentNumber(30);
		d3.setDepartmentName("Purchase");
		d3.setDepartmentLocation("Delhi");
		
		
		MyEmployee e1 = new MyEmployee(101,"Jack",5000,d2); //Testing dept 
		MyEmployee e2 = new MyEmployee(102,"Jane",6000,d2); //Testing dept
		MyEmployee e3 = new MyEmployee(103,"Jim",7000,d2); //Testing dept
		MyEmployee e4 = new MyEmployee(104,"Jackie",8000,d2); //Testing dept
		MyEmployee e5 = new MyEmployee(105,"John",9000,d3); // Purchase dept
		
		Set<MyEmployee> empSet1 = new HashSet<MyEmployee>();
		 
		empSet1.add(e1); //call to each add means - insert query
		empSet1.add(e2);
		empSet1.add(e3);
		empSet1.add(e4);
		empSet1.add(e5);
		
		d2.setEmployees(empSet1); // assign the set of emps to d2
		
		//===========================================================
		
		MyEmployee e6 = new MyEmployee(106,"Haresh",5500,d2); 
		MyEmployee e7 = new MyEmployee(107,"Rakesh",6500,d3);
		MyEmployee e8 = new MyEmployee(108,"Jayesh",7500,d3);
		MyEmployee e9 = new MyEmployee(109,"Naresh",8500,d3);
		MyEmployee e10 = new MyEmployee(110,"Ramesh",9500,d3);
		
		Set<MyEmployee> empSet2 = new HashSet<MyEmployee>();
		
		empSet2.add(e6);
		empSet2.add(e7);
		empSet2.add(e8);
		empSet2.add(e9);
		empSet2.add(e10);
		
		d3.setEmployees(empSet2);
	
		BaseDAO dao = new BaseDAO();
		dao.merge(d2);
		dao.merge(d3);
	}
	
}
