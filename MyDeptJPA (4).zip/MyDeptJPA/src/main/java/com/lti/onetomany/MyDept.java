package com.lti.onetomany;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity //i willbe back at my desk in 5mnt
@Table(name="mydept")
public class MyDept {
	
	@Id
	@Column(name="deptno", length=5)
	int departmentNumber;
	
	@Column(name="dname", length=10)
	String departmentName;
	
	@Column(name="loc", length=10)
	String departmentLocation;
	
	@OneToMany(mappedBy = "department", cascade = CascadeType.ALL) // relationship here
	Set <MyEmployee> employees;   
	     
//generate getters/setters in both pojos
	public int getDepartmentNumber() {
		return departmentNumber;
	}

	public void setDepartmentNumber(int departmentNumber) {
		this.departmentNumber = departmentNumber;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public String getDepartmentLocation() {
		return departmentLocation;
	}

	public void setDepartmentLocation(String departmentLocation) {
		this.departmentLocation = departmentLocation;
	}

	public Set<MyEmployee> getEmployees() {
		return employees;
	}

	public void setEmployees(Set<MyEmployee> employees) {
		this.employees = employees;
	}

	
	     
	     
	     
	     
	
}
