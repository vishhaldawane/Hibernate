package com.lti.onetomany;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="myemp")
public class MyEmployee { // a pojo name must be singular 

	@Id
	@Column(name="empno")
	int employeeNumber;
	
	@Column(name="ename",length=10)
	String employeeName;
	
	@Column(name="sal")
	double  employeeSalary;
	
	@ManyToOne
	@JoinColumn(name="dno")
	MyDept department; //as well as the setter method for this is imp

	public MyEmployee(int employeeNumber, String employeeName, double employeeSalary, 
			MyDept department) {
		super();
		this.employeeNumber = employeeNumber;
		this.employeeName = employeeName;
		this.employeeSalary = employeeSalary;
		this.department = department; //important aspect here
	}

	public MyEmployee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getEmployeeNumber() {
		return employeeNumber;
	}

	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public double getEmployeeSalary() {
		return employeeSalary;
	}

	public void setEmployeeSalary(double employeeSalary) {
		this.employeeSalary = employeeSalary;
	}

	public MyDept getDepartment() {
		return department;
	}

	public void setDepartment(MyDept department) {
		this.department = department;
	}

	
	
	
	
	
}
