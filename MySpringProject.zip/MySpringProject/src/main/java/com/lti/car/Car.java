package com.lti.car;

public class Car {
	
	Engine engine;
	String model;	
	
	
	public Car(Engine e) {
		System.out.println("Car(Engine e) ctor....");
		engine = e;
	}
	

	public Car(Engine e, String m) {
		System.out.println("Car(Engine e, String m) ctor....");
		engine = e;
		model = m;
	}
	public void run() {
		System.out.println(model+" Car is running....");
		
	}
}
