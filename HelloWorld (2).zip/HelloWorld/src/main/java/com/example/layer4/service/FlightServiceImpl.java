package com.example.layer4.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.layer2.entity.FlightDetails;
import com.example.layer3.repository.FlightRepository;
@Service
public class FlightServiceImpl implements FlightService {// BUSINESS LOGIC OF YOUR PROJECT
	
	@Autowired
	FlightRepository flightRepository; //service is talking to repository
	
	@Override // Repositories <---> Service <----> Controller(SpringMVC) <---> Angular CR-RA-UD
	public List<FlightDetails> getAllFlightsService() { //service invoking repository
		List<FlightDetails> listOfFlights = null;
		//take some business decisionshere 
		//take some business decisionshere 
		listOfFlights = flightRepository.getAllFlights();
		//take some business decisionshere 
		//take some business decisionshere 
		return listOfFlights;
	}

}

/*@Autowired	AccountRepository ac;	@Autowired	TransferFundsRepository tfr;
void fundTransferService(s, t, a) {
		Account src = ac.getAccount(s); Account trg = ac.getAccount(s);
		if("todaysday is sunday "  && "the type of transfer is neft"angular)
			throw NeftNotOnholidayException("");
		else
			if(src.getBal() > a) { //if the src account bal is more than a
			trg.setBalance(trg.getBalance()+a);
			src.setBalance(src.getBalance()-a);
			tfr.transferFunds(s,t);
		}
		else {
			throw new InSufficientBalanceAtSource();
}
}
*/

/*layer1(tbsl)    layer2(pojo)  layer3(repos)  layer4(service)  
 * 													|json
 * 									-----------------------------------
 * 									|				|			|
 * 								layer5(mvc)			ATM		phone
 * 									|				|			|
 * 								layer6(angular)		client		sms

						BankApp
							|
		Enterprise Application Server -- spring container
WebSphere|WebLogic|Jboss		|			
					------------------------
					|			|
		WebContainer(springmvc)	EJBContainer
								|
			--------------------------------------
			|		|		|		|		|
			getBal	getBal getBal getBal  getBal
			PC		ATM		VISA	Android	Phone
			|		|		  |		|		|
			|		app    machine  mobile  sms/IVR  GETBAL 56575
		browser		<------non-http--------->
html+css+ts|
			Chrome
	http://localhost:port/App/pagesORResources
*/