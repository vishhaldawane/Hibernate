package com.example.layer3.repository;

import java.util.List;

import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.layer2.entity.FlightDetails;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Repository
public class FlightRepositoryImpl implements FlightRepository {

	@PersistenceContext
	EntityManager entityManager; //CHEF
	
	@Transactional
	public List<FlightDetails> getAllFlights() { //this man will only communicate with CHEF 
		Query query = entityManager.createQuery(" from FlightDetails");
		List<FlightDetails> flightList = query.getResultList();
		return flightList;
	}

	public List<FlightDetails> getAllFlights(String source)
	{
		String queryString = "select f from FlightDetails f where f.sourceName ="+source;
	    List<FlightDetails> list = entityManager.createQuery(queryString).getResultList();
	    return list;	
	}
	
	public List<FlightDetails> getAllFlights(String source, String dest)
	{ //JPQL
		String queryString = "select f from "
				+ "FlightDetails f where "
				+ "f.sourceName=:src and f.destinationName=:dst";
		List<FlightDetails> list = 
		entityManager.createQuery(queryString)
	    			   .setParameter("src", source)
	    			   .setParameter("dst", dest)
	    			   .getResultList();
	    return list;	
	}
	

	@Transactional
	public void  addFlight(FlightDetails fd) {
		entityManager.persist(fd);
	}
}

/*
public class AccountRepository { //CHEF - DATA LOGIC 
	Account getAccount(int acno) { return em.find(acno); }
}
public class TransferFundsRepository {
	void transferFunds(Account src, Account trg) {
		em.merge(src); em.merge(trg);
	}
}

*/