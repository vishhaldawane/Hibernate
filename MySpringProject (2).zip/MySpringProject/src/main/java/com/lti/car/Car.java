package com.lti.car;

public class Car {
	
	Engine engine; //setter method for this
	String model; //setter method for this	 
	
	public Car() {
		System.out.println("Car()....Explicit No-Arg ctor...");
	}
	//to invoke the constructor 
	//use <constructor-arg> tag is used
	public Car(Engine e) { //invoked only once during instantiation 
		System.out.println("Car(Engine e) ctor....");
		engine = e;
	}
	public Car(Engine e, String m) {
		System.out.println("Car(Engine e, String m) ctor....");
		engine = e;
		model = m;
	}
	//<property name="lookAndFeel"> tag - spring will convert into setLookAndFeel
	void setLookAndFeel() { 
		
	}
	//setCar is the name <- to invoke such setter methods
	//use one tag knownas <property name="car"> tag
	public void setCar(Engine e) { //invoked after instantiation, as many times
		System.out.println("setCar(Engine e) ....");
		engine = e;
	}

	public void setModel(String m) {
		System.out.println("setModel(String m) ....");
		model = m;
	}
	
	public void run() {
		System.out.println(model+" Car is running....");
		
	}
}
