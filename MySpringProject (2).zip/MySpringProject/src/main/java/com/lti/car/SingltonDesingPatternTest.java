package com.lti.car;
public class SingltonDesingPatternTest {
	public static void main(String[] args) {

//		Class   Ref  Allocator	Constructor	
		System.out.println("Prototype way....");
		Kitchen k4 = new 		Kitchen();
		Kitchen k5 = new 		Kitchen();
		Kitchen k6 = new 		Kitchen();
		
		System.out.println("k4 "+k4); // toString()-> hashCode();
		System.out.println("k5 "+k5);
		System.out.println("k6 "+k6);
		
		System.out.println("\nSinglton way....");
		
		Kitchen k1 = Kitchen.getKitchen(); //class's method
		Kitchen k2 = Kitchen.getKitchen();
		Kitchen k3 = Kitchen.getKitchen();
		System.out.println("k1 "+k1); // toString()-> hashCode();
		System.out.println("k2 "+k2);
		System.out.println("k3 "+k3);
		
		System.out.println("\nSinglton way....via static block");
		
		Kitchen k7 = Kitchen.getKitchenInstance(); //class's method
		Kitchen k8 = Kitchen.getKitchenInstance();
		Kitchen k9 = Kitchen.getKitchenInstance();
		System.out.println("k1 "+k7); // toString()-> hashCode();
		System.out.println("k2 "+k8);
		System.out.println("k3 "+k9);

	}
}	
class Kitchen
{
	private static Kitchen ref; //shared instance | default is null 
	
	Kitchen() { 
		System.out.println("Kitchen Ctor invoked...");
	}
	public static Kitchen getKitchen() 
	{ 
		System.out.println("getKitchen() invoked..");
		if(ref==null)
		ref = new Kitchen(); //not an error
		return ref ;
	}
	
	public static Kitchen getKitchenInstance() {
		return ref;
	}
	static  // only one time execution 
	{ 
		System.out.println("static block of Kitchen invoked..");
		ref = new Kitchen();
	}
}
/*


		ref = new Kitchen();300
		|
		300
	
*/