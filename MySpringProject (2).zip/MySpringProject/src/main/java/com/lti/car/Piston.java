package com.lti.car;

public class Piston {
	public Piston(int i) {
		System.out.println("Piston(int) ctor...");
	}
	public Piston() {
		System.out.println("Piston() ctor...");
	}
}
