package com.lti.jpa;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:myspring-jpa.xml")
public class TestSpringORM {
	@Autowired
	MyDeptRepository myDeptRepository ;
	
	@Test
	public void testDept() {
			MyDept myDept = new MyDept(); 
			myDept.setDepartmentNumber(50);
			myDept.setDepartmentName("Fun");
			myDept.setDepartmentLocation("FunZone");
			myDeptRepository.addDepartment(myDept);
	}
}
