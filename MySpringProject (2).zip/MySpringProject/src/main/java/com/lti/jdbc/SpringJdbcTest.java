package com.lti.jdbc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringJdbcTest {
	public static void main(String[] args) {
		
		ApplicationContext container = 
				new ClassPathXmlApplicationContext("myspring-jdbc.xml");
		
						System.out.println("Loaded the container...."+container);
			
			MyDept      deptObj  = (MyDept)    container.getBean("myDept");
			
			deptObj.setDepartmentNumber(40);
			deptObj.setDepartmentLocation("Mumbai");
			deptObj.setDepartmentName("Quality");
			
			
			MyDeptDAO 	deptDao = (MyDeptDAO) container.getBean("myDeptDAO");
	
			deptDao.insertDepartmentRecord(deptObj);
		 
				
	}
}
