package com.lti.jdbc;

public interface MyDeptDAO {
	public void insertDepartmentRecord(MyDept d);
} //for 5 mnts IM away from my DESK
