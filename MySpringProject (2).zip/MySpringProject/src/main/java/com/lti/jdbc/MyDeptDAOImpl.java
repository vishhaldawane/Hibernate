package com.lti.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.DataSource;

/*
 * 
 * DriverManagerDataSource dmds = new DriverManagerDataSource();
 * MyDeptDAOImpl mddi = new MyDeptDAOImpl();
 * 
 * mddi.setDataSource(dmds);
 * 
 * 
 */

public class MyDeptDAOImpl /*Car*/ implements MyDeptDAO {	//Engine			
	DataSource dataSource; // spring will invoke the setter method
public void setDataSource(DataSource ds) {  	System.out.println("setDataSource() invoked...");					//setEngine
	dataSource = ds;
}
public void insertDepartmentRecord(MyDept d) { //run () interface mandate
	Connection conn = null;
	try {
		conn = dataSource.getConnection();	System.out.println("Connected to the database : "+conn);
			
		PreparedStatement pst =
			conn.prepareStatement("insert into mydept (DEPTNO,LOC,DNAME) values (?,?,?)");
		System.out.println("Statement prepared..");
		pst.setInt(1, d.getDepartmentNumber());
			pst.setString(2, d.getDepartmentLocation());
			pst.setString(3, d.getDepartmentName());
			int row = pst.executeUpdate();	System.out.println("query executed..");
			
			System.out.println(row+" Row inserted...");
			pst.close();		conn.close();
		} catch (SQLException e) {			e.printStackTrace();		}
	}
}
